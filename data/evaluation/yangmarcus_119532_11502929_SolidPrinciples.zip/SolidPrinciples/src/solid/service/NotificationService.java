package solid.service;

import solid.service.senders.EmailNotificationSender;
import solid.service.senders.NotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {

    private final Map<String, NotificationSender> senders = new HashMap<>();

    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
    }

    public void sendNotification(User user, String message, String type) {
        NotificationSender sender = senders.get(type);
        if (sender == null) {
            throw new UnsupportedOperationException("Unsupported notification type: " + type);
        }
        sender.send(user, message);
    }
}