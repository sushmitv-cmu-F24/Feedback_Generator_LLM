package solid.service;

import java.util.HashMap;
import java.util.Map;

import solid.service.sender.EmailNotificationSender;
import solid.service.sender.NotificationSender;
import solid.service.sender.PushNotificationSender;
import solid.service.sender.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

/**
 * NofiticationService
 */
public class NotificationService {

    private final Map<String, NotificationSender> senders = new HashMap<>();
    // Method to send a notification based on notification type

    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
    }

    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender = senders.get(notificationType);
        if(sender != null) {
            if(notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
                throw new UnsupportedOperationException("Regular user does not support push notifications");
            }
            sender.send(user, message);
        } else {
            throw new IllegalArgumentException("Unknown notification type: "+ notificationType);
        }
    }

}