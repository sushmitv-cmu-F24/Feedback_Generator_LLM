package solid.service.sender;

import solid.user.User;

public class PushNotificationSender implements NotificationSender{
    @Override
    public void send(User user, String message) {
        if(!user.role.equals("admin")){
            throw new UnsupportedOperationException("Regular user does not support push notifications");
        }else{
            System.out.println("Sending PUSH to " + user.getUsername() + " -> " + message);;
        }
    }
}
