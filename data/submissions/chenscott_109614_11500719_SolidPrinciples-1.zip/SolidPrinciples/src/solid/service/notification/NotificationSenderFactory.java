package solid.service.notification;

public class NotificationSenderFactory {

    public static NotificationSender getSender(String notificationType) {
        switch (notificationType.toUpperCase()) {
            case "EMAIL":
                return new EmailNotificationSender();
            case "SMS":
                return new SMSNotificationSender();
            case "PUSH":
                return new PushNotificationSender();
            default:
                throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}