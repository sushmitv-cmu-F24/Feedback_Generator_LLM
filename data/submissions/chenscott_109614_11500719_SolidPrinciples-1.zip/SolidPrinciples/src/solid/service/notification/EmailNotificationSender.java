package solid.service.notification;

import solid.user.User;

public class EmailNotificationSender implements NotificationSender {

    @Override
    public void sendNotification(User user, String message) {
        System.out.println("Sending EMAIL to " + user.getUsername() + " -> " + message);
    }
}