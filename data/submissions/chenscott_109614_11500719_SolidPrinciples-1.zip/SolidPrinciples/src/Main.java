import solid.service.notification.NotificationService;
import solid.persistence.drivers.PostgresDriver;
import solid.service.UserService;
import solid.user.AdminUser;
import solid.user.User;

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------Adding users-------------------------");
        // Create User instances
        User user1 = new User(1, "john_doe", 25, 100000);
        User user2 = new User(2, "alice_smith", 35, 100000);
        User user3 = new AdminUser(0, "bob_jones", 65, 100000, true);

        PostgresDriver postgresDriver = new PostgresDriver();
        UserService userService = new UserService(postgresDriver);
        NotificationService notificationService = new NotificationService();

        // Save users 1 and 2 using RegularUserService
        userService.addUser(user1);
        userService.addUser(user2);
        userService.addUser(user3);

        System.out.println("\n------------------Sending notifications-------------------------");

        // Send notifications using different services
        notificationService.sendTaxNotification(user1, "Pay your taxes!", "EMAIL");
        notificationService.sendTaxNotification(user2, "Pay your taxes!", "SMS");
        // regularUserService.sendTaxNotification(user2, "Pay your taxes!", "PUSH");
        // //This breaks the code

        notificationService.sendTaxNotification(user3, "Pay your taxes!", "PUSH");

        System.out.println("\n------------------Fetching users-------------------------");

        // Fetch and display user by ID -> there is an encapsulation violation here ->
        // bug proneness
        userService.getUserById(1);
        userService.getUserById(0);

        System.out.println("\n------------------Deleting users-------------------------");
        // Delete accounts
        userService.removeUser(user1);
        userService.removeUser(user2);
        if (user3 instanceof AdminUser) {
            AdminUser adminUser = (AdminUser) user3;
            if (!adminUser.hasSuperAdminRights()) {
                userService.removeUser(adminUser);
            } else {
                System.out.println("Cannot delete admin user with super admin rights: " + adminUser.getUsername());
            }
        } else {
            userService.removeUser(user3);
        }

    }
}