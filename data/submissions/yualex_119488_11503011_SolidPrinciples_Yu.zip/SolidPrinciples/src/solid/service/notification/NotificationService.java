package solid.service.notification;

import solid.user.User;

public class NotificationService {
    public void sendTaxNotification(User user, String message, String method) {
        NotificationSender sender = NotificationFactory.getNotificationSender(method);
        sender.sendNotification(user, message);
    }
}