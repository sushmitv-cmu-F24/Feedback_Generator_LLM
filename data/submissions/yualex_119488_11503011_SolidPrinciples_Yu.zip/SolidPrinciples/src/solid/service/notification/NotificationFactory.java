package solid.service.notification;

public class NotificationFactory {
    public static NotificationSender getNotificationSender(String method) {
        switch (method) {
            case "EMAIL":
                return new EmailNotificationSender();
            case "SMS":
                return new SMSNotificationSender();
            case "PUSH":
                return new PushNotificationSender();
            default:
                throw new IllegalArgumentException("Unknown notification method: " + method);
        }
    }
    
}
