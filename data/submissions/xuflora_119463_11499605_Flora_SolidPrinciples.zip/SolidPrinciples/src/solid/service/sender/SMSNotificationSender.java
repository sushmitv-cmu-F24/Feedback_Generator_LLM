package solid.service.sender;

import solid.user.User;
public class SMSNotificationSender implements NotificationSender{
    @Override
    public void send(User user, String message) {
        System.out.println("Sending SMS to " + user.getUsername() + " -> " + message);
    }

}
