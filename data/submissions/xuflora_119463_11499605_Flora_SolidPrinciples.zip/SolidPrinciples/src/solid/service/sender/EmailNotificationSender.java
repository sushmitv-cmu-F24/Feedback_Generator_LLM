package solid.service.sender;

import solid.user.User;

public class EmailNotificationSender implements NotificationSender{
    @Override
    public void send(User user, String message) {
        System.out.println("Sending EMAIL to " + user.getUsername() + " -> " + message);
    }
}
