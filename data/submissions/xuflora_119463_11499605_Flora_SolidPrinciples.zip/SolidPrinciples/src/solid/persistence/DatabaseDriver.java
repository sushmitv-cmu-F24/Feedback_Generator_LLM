package solid.persistence;

import solid.user.User;

public interface DatabaseDriver {

    boolean save(User user);

    User query(int id);

    boolean delete(int id);
}
