package solid.service.notification;

import solid.user.User;

public class NotificationService {
    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender;
        switch (notificationType) {
            case "EMAIL":
                sender = new EmailNotificationSender();
                break;
            case "SMS":
                sender = new SMSNotificationSender();
                break;
            case "PUSH":
                sender = new PushNotificationSender();
                break;
            default:
                throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
        sender.send(user, message);
    }
}
