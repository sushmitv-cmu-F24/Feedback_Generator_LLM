import solid.service.UserService;
import solid.service.notification.NotificationService;
import solid.persistence.DatabaseDriver;
import solid.persistence.PostgresDriver;
import solid.user.User;
import solid.user.AdminUser;

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------Adding users-------------------------");
        // Create User instances
        User user1 = new User(1, "john_doe", 25, 100000);
        User user2 = new User(2, "alice_smith", 35, 100000);
        User user3 = new AdminUser(0, "bob_jones", 65, 100000, true);

        DatabaseDriver databaseDriver = new PostgresDriver();
        NotificationService notificationService = new NotificationService();
        UserService userService = new UserService(databaseDriver, notificationService);

        // Save users using RegularUserService
        userService.addUser(user1);
        userService.addUser(user2);
        userService.addUser(user3);

        System.out.println("\n------------------Sending notifications-------------------------");

        // Send notifications using different services
        userService.sendTaxNotification(user1, "Pay your taxes!", "EMAIL");
        userService.sendTaxNotification(user2, "Pay your taxes!", "SMS");
        userService.sendTaxNotification(user3, "Pay your taxes!", "PUSH");

        System.out.println("\n------------------Fetching users-------------------------");

        // Fetch and display users by ID
        userService.getUserById(1);
        userService.getUserById(0);

        System.out.println("\n------------------Deleting users-------------------------");
        // Delete accounts
        userService.removeUser(user1);
        userService.removeUser(user2);
        userService.removeUser(user3);

        // Try to delete admin user again (should not be deleted due to super admin rights)
        userService.removeUser(user3);
    }
}