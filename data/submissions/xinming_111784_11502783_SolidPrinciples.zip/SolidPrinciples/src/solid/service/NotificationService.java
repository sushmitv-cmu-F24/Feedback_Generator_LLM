package solid.service;

import java.util.HashMap;
import java.util.Map;

import solid.service.senders.EmailNotificationSender;
import solid.service.senders.NotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

public class NotificationService {
    private final Map<String, NotificationSender> senderMap = new HashMap<>();

    public NotificationService() {
        senderMap.put("EMAIL", new EmailNotificationSender());
        senderMap.put("SMS", new SMSNotificationSender());
        senderMap.put("PUSH", new PushNotificationSender());
    }

    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender = senderMap.get(notificationType);
        if (sender != null) {
            if (notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
                throw new UnsupportedOperationException("Regular users cannot receive push notifications.");
            }
            sender.send(user, message);
        } else {
            throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}
