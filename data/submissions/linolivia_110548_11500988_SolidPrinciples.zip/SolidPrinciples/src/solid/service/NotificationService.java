package solid.service;

import solid.service.senders.NotificationSender;
import solid.user.User;

public class NotificationService {
    private NotificationSender notificationSender;

    public NotificationService(NotificationSender notificationSender) {
        this.notificationSender = notificationSender;
    }

    public void sendNotification(User user, String message) {
        notificationSender.sendNotification(user, message);
    }
}
