package solid.persistence;

import solid.service.drivers.DatabaseDriver;

import solid.user.User;

import java.util.HashMap;

public class PostgresDriver implements DatabaseDriver {
    private static HashMap<Integer, User> users = new HashMap<>();

    @Override
    public boolean save(User user) {
        System.out.println("Executing Save SQL: " + user);
        users.put(user.getId(), user);
        return true;
    }

    @Override
    public User query(int id) {
        System.out.println("Executing SQL query");
        return users.getOrDefault(id, null);
    }

    @Override
    public boolean delete(int id) {
        System.out.println("Executing SQL delete");
        return users.remove(id) != null;
    }
}
