import solid.service.NotificationService;
import solid.service.UserService;
import solid.service.senders.EmailNotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------Adding users-------------------------");

        User user1 = new User(1, "john_doe", 25, 100000);
        User user2 = new User(2, "alice_smith", 35, 100000);
        User user3 = new AdminUser(0, "bob_jones", 65, 100000, true);

        UserService userService = new UserService();

        // Save users 1 and 2 using UserService
        userService.addUser(user1);
        userService.addUser(user2);
        userService.addUser(user3);

        System.out.println("\n------------------Sending notifications-------------------------");

        // Send notifications
        NotificationService emailService = new NotificationService(new EmailNotificationSender());
        emailService.sendNotification(user1, "Pay your taxes!");

        NotificationService smsService = new NotificationService(new SMSNotificationSender());
        smsService.sendNotification(user2, "Pay your taxes!");

        NotificationService pushService = new NotificationService(new PushNotificationSender());
        pushService.sendNotification(user3, "Pay your taxes!");

        System.out.println("\n------------------Fetching users-------------------------");
        userService.getUserById(1);
        userService.getUserById(0);

        System.out.println("\n------------------Deleting users-------------------------");
        userService.removeUser(user1);
        userService.removeUser(user2);
        userService.removeUser(user3);
    }
}
