package solid.persistence;

import solid.user.User;

/**
 * Interface for database operations.
 */
public interface DatabaseDriver {
    boolean save(User user);
    User query(int id);
    boolean delete(int id);
}
