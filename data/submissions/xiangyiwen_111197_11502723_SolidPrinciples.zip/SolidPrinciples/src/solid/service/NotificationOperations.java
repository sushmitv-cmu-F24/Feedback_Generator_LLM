package solid.service;

import solid.user.User;

/**
 * NotificationOperations interface with a single responsibility: sending notifications.
 */
public interface NotificationOperations {
    void sendEmailNotification(User user, String message);
    void sendSMSNotification(User user, String message);
    void sendPushNotification(User user, String message);
}
