package solid.service;

import solid.user.User;

/**
 * UserOperations interface with a single responsibility: user management.
 */
public interface UserOperations {
    void addUser(User user);
    void removeUser(User user);
}
