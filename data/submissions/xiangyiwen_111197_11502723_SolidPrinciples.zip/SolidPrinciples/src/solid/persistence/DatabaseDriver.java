package solid.persistence;

/**
 * DatabaseDriver interface defines the behavior of a generic database driver.
 */
import solid.user.User;

public interface DatabaseDriver {
    boolean save(User user);
    User query(int id);
    boolean delete(int id);
}
