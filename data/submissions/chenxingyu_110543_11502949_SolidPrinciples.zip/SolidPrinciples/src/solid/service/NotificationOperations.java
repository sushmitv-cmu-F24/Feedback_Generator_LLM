package solid.service;

import solid.user.User;

public interface NotificationOperations {
    void sendEmailNotification(User user, String message);

    void sendSMSNotification(User user, String message);

    void sendPushNotification(User user, String message);
}
