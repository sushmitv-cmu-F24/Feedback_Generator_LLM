package solid.service;

import solid.persistence.DatabaseDriver;
import solid.user.User;

public class AdminUserService extends UserService {
    public AdminUserService(DatabaseDriver databaseDriver) {
        super(databaseDriver);
    }

    public void sendPushNotification(User user, String message) {
        System.out.println("Sending PUSH to " + user.getUsername() + " -> " + message);;
    }
}
