package solid.service.senders;

import solid.user.User;

public class PushNotificationSender implements NotificationSender {
    @Override
    public void send(User user, String message) {
        System.out.println("Sending PUSH to " + user.getUsername() + " -> " + message);;
    }
}
