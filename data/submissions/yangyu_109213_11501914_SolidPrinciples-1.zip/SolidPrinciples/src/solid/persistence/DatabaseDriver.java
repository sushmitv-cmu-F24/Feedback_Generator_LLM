package solid.persistence;

import solid.user.User;

/**
 * DatabaseDriver interface defines the contract for database operations.
 * It allows UserService to depend on this abstraction rather than a concrete implementation.
 */
public interface DatabaseDriver {
    boolean save(User user);
    User query(int id);
    boolean delete(int id);
}