package solid.service;

import solid.service.senders.NotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.service.senders.EmailNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {
    private static final Map<String, NotificationSender> senders = new HashMap<>();

    public NotificationService() {
        senders.put("PUSH", new PushNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("EMAIL", new EmailNotificationSender());
        // Could add more senders here
    }


    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender = senders.get(notificationType);
        // If the sender is null, then the notification type is invalid
        if (sender == null) {
            throw new IllegalArgumentException("Invalid notification type: " + notificationType);
        }

        // TODO: Refactor this logic
        // Non admin users should not be able to send PUSH notifications
        if (notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
            throw new UnsupportedOperationException("Non admin users cannot send PUSH notifications");
        }

        sender.send(user, message);
    }

}