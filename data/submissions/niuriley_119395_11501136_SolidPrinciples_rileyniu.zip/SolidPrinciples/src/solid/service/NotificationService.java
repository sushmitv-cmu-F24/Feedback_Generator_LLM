package solid.service;

import solid.user.User;
import solid.user.AdminUser;
import solid.service.senders.EmailNotificationSender;
import solid.service.senders.NotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;

import java.util.Map;
import java.util.HashMap;

// Extract delegate refactoring
public class NotificationService {
    // map the channel to senders
    private final Map<String, NotificationSender> senders = new HashMap<>();

    public NotificationService() {
        // create factory
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());

        // add more if needed
    }

    public void sendNotification(User user, String message, String channel) {
        NotificationSender sender = senders.get(channel);
        if (sender != null) {
            if (channel.equals("PUSH")){
                if (user instanceof AdminUser){
                    sender.sendNotification(user, message);
                }
            } else {
                sender.sendNotification(user, message);
               
            }
        } else {
            throw new IllegalArgumentException("No such channel: " + channel);
        }
        
    }
}