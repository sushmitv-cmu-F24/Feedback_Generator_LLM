import solid.service.UserService;
import solid.user.AdminUser;
import solid.user.User;
import solid.persistence.drivers.PostgresDriver;

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------Adding users-------------------------");
        // Create User instances
        User user1 = new User(1, "john_doe", 25, 100000);
        User user2 = new User(2, "alice_smith", 35, 100000);
        User user3 = new AdminUser(0, "bob_jones", 65, 100000, true);

        PostgresDriver postgresDriver = new PostgresDriver();
        UserService UserService = new UserService(postgresDriver);

        // Save users 1 and 2 using RegularUserService
        UserService.addUser(user1);
        UserService.addUser(user2);

        UserService.addUser(user3);

        // ABOVE: all added to a same hashmap


        System.out.println("\n------------------Sending notifications-------------------------");

        // Send notifications using different services
        UserService.sendTaxNotification(user1, "Pay your taxes!", "EMAIL");
        UserService.sendTaxNotification(user2, "Pay your taxes!", "SMS");
        UserService.sendTaxNotification(user2, "Pay your taxes!", "PUSH"); //This breaks the code

        UserService.sendTaxNotification(user3, "Pay your taxes!", "PUSH");

        System.out.println("\n------------------Fetching users-------------------------");

        // Fetch and display user by ID -> there is an encapsulation violation here -> bug proneness
        UserService.getUserById(1);
        UserService.getUserById(0);

        System.out.println("\n------------------Deleting users-------------------------");
        // Delete accounts - all mixed here because they're doing essentially the same thing
        UserService.removeUser(user1);
        UserService.removeUser(user2);
        UserService.removeUser(user3);

        UserService.removeUser(user3);

    }
}