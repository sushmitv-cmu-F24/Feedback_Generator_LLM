package solid.service;

import solid.user.User;

/**
 * Low Cohesion:</b> The <code>UserOperations</code> interface is too broad and covers multiple
 * responsibilities (user management and notification sending), which are unrelated for some implementing classes.
 */

// two types of responsibility: managing users and managing notification. single responsibility violated
// when making changes to notification type, needs to modify subclasses. open-close principle violated
public interface UserOperations {
    void addUser(User user);
    void removeUser(User user);
}

