package solid.service;

import solid.senders.EmailNotificationSender;
import solid.senders.NotificationSender;
import solid.senders.PushNotificationSender;
import solid.senders.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {
    private final Map<String, NotificationSender> senders = new HashMap<>();
    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
        // add more senders as needed without a lot of modifications
    }

    public void sendNotification(User user, String message, String notificationType){
        NotificationSender sender = senders.get(notificationType);
        if(sender != null) {
            // TODO: refactor this code
            if(notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
                throw new UnsupportedOperationException("regular users cannot push");
            }
            sender.send(user, message);
        } else {
            throw new UnsupportedOperationException("no notification type");
        }
    }
}