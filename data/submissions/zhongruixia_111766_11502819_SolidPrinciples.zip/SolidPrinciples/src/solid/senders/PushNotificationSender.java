package solid.senders;

import solid.user.AdminUser;
import solid.user.User;

public class PushNotificationSender implements NotificationSender{
    @Override
    public void send(User user, String message) {
        if(user instanceof AdminUser){
            System.out.println("Sending PUSH to " + user.getUsername() + " -> " + message);
        }
        else{
            throw new UnsupportedOperationException("Only Admin users can send PUSH notifications");
        }
    }
}
