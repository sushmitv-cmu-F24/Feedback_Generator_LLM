package solid.service;

import solid.senders.EmailNotificationSender;
import solid.senders.NotificationSender;
import solid.senders.PushNotificationSender;
import solid.senders.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {
    private Map<String, NotificationSender> notificationSenders = new HashMap<>();
    public NotificationService() {
        notificationSenders.put("EMAIL", new EmailNotificationSender());
        notificationSenders.put("SMS", new SMSNotificationSender());
        notificationSenders.put("PUSH", new PushNotificationSender());
    }

    public void sendNotification(User user, String notificationType, String message) {
        NotificationSender notificationSender = notificationSenders.getOrDefault(notificationType,null);
        if( notificationSender == null){
            throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
        if(notificationType.equals("PUSH") && !(user instanceof AdminUser)){
            throw new UnsupportedOperationException("Only Admin users can send PUSH notifications");
        }
        else{
            notificationSender.send(user, message);
        }
    }



}