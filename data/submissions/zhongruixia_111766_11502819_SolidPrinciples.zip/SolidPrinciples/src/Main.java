import solid.persistence.DatabaseDriver;
import solid.persistence.drivers.PostgresDatabaseDriver;
import solid.service.UserService;
import solid.user.AdminUser;
import solid.user.User;

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------Adding users-------------------------");
        // Create User instances
        User user1 = new User(1, "john_doe", 25, 100000);
        User user2 = new User(2, "alice_smith", 35, 100000);
        User user3 = new AdminUser(0, "bob_jones", 65, 100000, true);

        DatabaseDriver databaseDriver = new PostgresDatabaseDriver();
        UserService userService = new UserService(databaseDriver);

        // Save users 1 and 2 using RegularUserService
        userService.addUser(user1);
        userService.addUser(user2);

        userService.addUser(user3);


        System.out.println("\n------------------Sending notifications-------------------------");

        // Send notifications using different services
        userService.sendTaxNotification(user1, "Pay your taxes!", "EMAIL");
        userService.sendTaxNotification(user2, "Pay your taxes!", "SMS");
        //regularUserService.sendTaxNotification(user2, "Pay your taxes!", "PUSH"); //This breaks the code

        userService.sendTaxNotification(user3, "Pay your taxes!", "PUSH");

        System.out.println("\n------------------Fetching users-------------------------");

        // Fetch and display user by ID -> there is an encapsulation violation here -> bug proneness
        userService.getUserById(1);
        userService.getUserById(0);

        System.out.println("\n------------------Deleting users-------------------------");
        // Delete accounts
        userService.removeUser(user1);
        userService.removeUser(user2);
        userService.removeUser(user3);
        userService.removeUser(user3);

    }
}