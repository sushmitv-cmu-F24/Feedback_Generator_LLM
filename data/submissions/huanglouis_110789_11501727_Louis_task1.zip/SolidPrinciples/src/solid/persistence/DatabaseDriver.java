package solid.persistence;

import solid.user.User;

public interface DatabaseDriver {
    public boolean save(User user);
    public User query(int id);
    public boolean delete(int id);
}
