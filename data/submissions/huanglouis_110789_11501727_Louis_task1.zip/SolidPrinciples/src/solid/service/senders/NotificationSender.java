package solid.service.senders;

import solid.user.User;

public interface NotificationSender {
    public void send(User user, String message);
}
