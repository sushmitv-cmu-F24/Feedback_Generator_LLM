package solid.service.senders;

import solid.user.User;

public interface NotificationSender {

    void send(User user, String message);
}
