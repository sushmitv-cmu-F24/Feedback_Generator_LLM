package solid.persistence;

import solid.user.User;

public interface DatabaseDriver {
    // Method to simulate a database query
    boolean save(User user);

    User query(int id);

    boolean delete(int id);
}
