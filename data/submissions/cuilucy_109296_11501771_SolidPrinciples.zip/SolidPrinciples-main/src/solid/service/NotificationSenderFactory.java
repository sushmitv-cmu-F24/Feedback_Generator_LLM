package solid.service;

import solid.service.senders.EmailNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.service.senders.PushNotificationSender;

public class NotificationSenderFactory {
    public static NotificationSender getNotificationSender(String notificationType) {
        switch (notificationType) {
            case "EMAIL":
                return new EmailNotificationSender();
            case "SMS":
                return new SMSNotificationSender();
            case "PUSH":
                return new PushNotificationSender();
            default:
                throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}