package solid.service;

import solid.user.User;

public interface DatabaseDriver {
    void save(User user);
    boolean delete(int userId);
    User query(int userId);
}
