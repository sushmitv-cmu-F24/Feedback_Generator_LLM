package solid.service;

import solid.user.User;

public interface NotificationSender {
    void sendNotification(User user, String message);
}
