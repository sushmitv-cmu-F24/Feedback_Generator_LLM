package solid.service;

import solid.user.User;

public class NotificationService {
    public void sendNotification(User user, String message, NotificationSender sender) {
        sender.sendNotification(user, message);
    }
}