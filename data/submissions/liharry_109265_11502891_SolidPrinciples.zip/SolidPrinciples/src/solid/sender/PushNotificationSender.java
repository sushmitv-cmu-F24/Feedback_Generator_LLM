package solid.sender;

import solid.user.User;

public class PushNotificationSender implements NotificationSender {
    @Override
    public void sendNotification(User user, String message) {
        System.out.println("Sending PUSH to " + user.getUsername() + " -> " + message);
    }
}
