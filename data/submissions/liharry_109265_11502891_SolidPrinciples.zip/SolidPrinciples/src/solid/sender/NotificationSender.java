package solid.sender;

import solid.user.User;

public interface NotificationSender {
    void sendNotification(User user, String message);
}
