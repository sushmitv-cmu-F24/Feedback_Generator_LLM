package solid.driver;

import solid.user.User;

import java.util.HashMap;

public interface DatabaseDriver {
    static HashMap<Integer, User> users = new HashMap<>();

    public boolean save(User user);

    public User query(int id);

    public boolean delete(int id);
}
