package solid.service;

import solid.sender.EmailNotificationSender;
import solid.sender.NotificationSender;
import solid.sender.PushNotificationSender;
import solid.sender.SMSNotificationSender;
import solid.user.User;

public class NotificationService  {
    public NotificationService() {
    }

    public void sendEmailNotification(User user, String message) {
        NotificationSender emailNotificationSender = new EmailNotificationSender();
        emailNotificationSender.sendNotification(user, message);
    }

    public void sendSMSNotification(User user, String message) {
        NotificationSender smsNotificationSender = new SMSNotificationSender();
        smsNotificationSender.sendNotification(user, message);
    }

    public void sendPushNotification(User user, String message) {
        NotificationSender pushNotificationSender = new PushNotificationSender();
        pushNotificationSender.sendNotification(user, message);
    }
}