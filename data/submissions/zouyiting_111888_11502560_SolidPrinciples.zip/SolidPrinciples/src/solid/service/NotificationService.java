package solid.service;

import solid.service.senders.EmailNotificationSender;
import solid.service.senders.NotificationSender;
import solid.service.senders.PushNotificationSender;
import solid.service.senders.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {
    private final Map<String, NotificationSender> senders = new HashMap<>();
    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
    }

    // Method to send a notification based on notification type
    public void sendTaxNotification(User user, String message, String notificationType) {
        NotificationSender sender = senders.get(notificationType);
        if (sender != null) {
            if (notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
                throw new UnsupportedOperationException("Regular user does not support push notifications.");
            }
            sender.send(user, message);
        } else {
            throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}