package solid.service;

import solid.service.sender.EmailNotificationSender;
import solid.service.sender.NotificationSender;
import solid.service.sender.PushNotificationSender;
import solid.service.sender.SMSNotificationSender;
import solid.user.User;
import solid.user.AdminUser;

import java.util.Map;
import java.util.HashMap;

public class NotificationService {
    private final Map<String, NotificationSender> senders = new HashMap<>();

    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        // Add more senders as needed without modifying (a lot) this class.
    }

    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender = senders.get(notificationType);
        if (sender != null) {
            // TODO: UGLY CODE TO BE FIXED -> REFACTORING NEEDED!
            if (notificationType.equals("PUSH") &&  !(user.getRole().equals("admin"))) {
                throw new UnsupportedOperationException("Regular user does not support push notification.");
            }
            sender.send(user, message);
        }
        else {
            throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}
