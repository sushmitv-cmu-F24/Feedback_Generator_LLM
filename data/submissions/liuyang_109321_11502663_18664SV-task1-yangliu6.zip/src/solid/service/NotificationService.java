package solid.service;

import solid.service.sender.EmailNotificationSender;
import solid.service.sender.NotificationSender;
import solid.service.sender.PushNotificationSender;
import solid.service.sender.SMSNotificationSender;
import solid.user.AdminUser;
import solid.user.User;

import java.util.HashMap;
import java.util.Map;

public class NotificationService {
    private final Map<String, NotificationSender> senders = new HashMap<>();

    public NotificationService() {
        senders.put("EMAIL", new EmailNotificationSender());
        senders.put("SMS", new SMSNotificationSender());
        senders.put("PUSH", new PushNotificationSender());
    }

    public void sendNotification(User user, String message, String notificationType) {
        NotificationSender sender = senders.get(notificationType);
        if (sender != null) {
            // TODO: refactor following
            if (notificationType.equals("PUSH") && !(user instanceof AdminUser)) {
                throw new UnsupportedOperationException("RegularUserService does not support sending push notifications.");
            }
            sender.send(user, message);
        } else {
            throw new IllegalArgumentException("Unknown notification type: " + notificationType);
        }
    }
}